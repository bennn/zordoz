`raco pgmp --profile stresstest.rkt`
cpu time: 108770 real time: 108726 gc time: 4689

`racket -t stresstest.rkt`
cpu time: 105903 real time: 105859 gc time: 4504
